package evswap.swp391to4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Swp391To4ApplicationTests {

    @Test
    void contextLoads() {
    }

}
