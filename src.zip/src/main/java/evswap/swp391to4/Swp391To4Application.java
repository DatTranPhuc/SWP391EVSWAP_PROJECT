package evswap.swp391to4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Swp391To4Application {

    public static void main(String[] args) {
        SpringApplication.run(Swp391To4Application.class, args);
    }

}
