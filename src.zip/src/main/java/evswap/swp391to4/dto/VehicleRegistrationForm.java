package evswap.swp391to4.dto;

import lombok.Data;

@Data
public class VehicleRegistrationForm {
    private String model;
    private String vin;
    private String plateNumber;
}
