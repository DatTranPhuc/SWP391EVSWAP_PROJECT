package evswap.swp391to4.controller;

import evswap.swp391to4.entity.Admin;
import evswap.swp391to4.entity.Driver;
import evswap.swp391to4.entity.Staff;
import evswap.swp391to4.repository.DriverRepository;
import evswap.swp391to4.service.AdminService;
import evswap.swp391to4.service.DriverService;
import evswap.swp391to4.service.StaffService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Optional;
import java.util.Random;

@Controller
@RequiredArgsConstructor
public class AuthController {

    private final DriverService driverService;
    private final StaffService staffService;
    private final AdminService adminService;
    private final DriverRepository driverRepository;
    private final JavaMailSender mailSender;
    private final PasswordEncoder passwordEncoder;

    // ===== LOGIN =====
    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String email,
                        @RequestParam String password,
                        HttpSession session,
                        RedirectAttributes redirect) {
        try {
            // --- DRIVER ---
            Driver driver = driverService.login(email, password);
            session.setAttribute("loggedInDriver", driver);
            redirect.addFlashAttribute("loginSuccess", "Chào " + driver.getFullName() + "!");
            return "redirect:/dashboard";
        } catch (Exception e1) {
            try {
                // --- STAFF ---
                Staff staff = staffService.login(email, password);
                session.setAttribute("loggedInStaff", staff);
                redirect.addFlashAttribute("loginSuccess", "Chào " + staff.getFullName() + "!");
                return "redirect:/staff/dashboard";
            } catch (Exception e2) {
                try {
                    // --- ADMIN ---
                    Admin admin = adminService.login(email, password);
                    session.setAttribute("loggedInAdmin", admin);
                    redirect.addFlashAttribute("loginSuccess", "Chào " + admin.getFullName() + "!");
                    return "redirect:/admin/dashboard";
                } catch (Exception e3) {
                    redirect.addFlashAttribute("loginError", "Sai email hoặc mật khẩu!");
                    return "redirect:/login";
                }
            }
        }
    }

    // ===== LOGOUT =====
    @PostMapping("/logout")
    public String logout(HttpSession session, RedirectAttributes redirect) {
        session.invalidate();
        redirect.addFlashAttribute("logoutMessage", "Đăng xuất thành công.");
        return "redirect:/login";
    }

    // ===== REGISTER =====
    @GetMapping("/register")
    public String registerPage() {
        return "register";
    }

    @PostMapping("/register")
    public String register(@RequestParam String email,
                           @RequestParam String password,
                           @RequestParam String fullName,
                           @RequestParam(required = false) String phone,
                           RedirectAttributes redirect) {
        try {
            Driver driver = Driver.builder()
                    .email(email)
                    .passwordHash(password)
                    .fullName(fullName)
                    .phone(phone)
                    .build();
            driverService.register(driver);
            redirect.addFlashAttribute("registerSuccess", "Đăng ký thành công! Vui lòng xác minh email.");
            redirect.addFlashAttribute("email", email);
            return "redirect:/verify";
        } catch (Exception e) {
            redirect.addFlashAttribute("registerError", e.getMessage());
            return "redirect:/register";
        }
    }

    // ===== VERIFY =====
    @GetMapping("/verify")
    public String verifyPage() {
        return "verify";
    }

    @PostMapping("/verify-otp")
    public String verifyOtp(@RequestParam String email,
                            @RequestParam String otp,
                            RedirectAttributes redirect) {
        try {
            Driver driver = driverService.verifyOtp(email, otp);
            redirect.addFlashAttribute("verifySuccess", "Xác minh email thành công!");
            return "redirect:/vehicles/register?driverId=" + driver.getDriverId();
        } catch (Exception e) {
            redirect.addFlashAttribute("verifyError", e.getMessage());
            redirect.addFlashAttribute("email", email);
            return "redirect:/verify";
        }
    }

    // ===== FORGOT PASSWORD =====
    @GetMapping("/forgot-password")
    public String forgotPasswordForm() {
        return "forgot-password";
    }

    @PostMapping("/forgot-password")
    public String handleForgotPassword(@RequestParam("email") @NotBlank String email,
                                       RedirectAttributes redirect) {
        Optional<Driver> opt = driverRepository.findByEmail(email);
        if (opt.isEmpty()) {
            redirect.addFlashAttribute("error", "Không tìm thấy tài khoản với email này.");
            return "redirect:/forgot-password";
        }

        Driver driver = opt.get();
        String otp = generateOtp();
        driver.setEmailOtp(otp);
        driver.setOtpExpiry(Instant.now().plus(10, ChronoUnit.MINUTES));
        driverRepository.save(driver);

        try {
            SimpleMailMessage msg = new SimpleMailMessage();
            msg.setTo(driver.getEmail());
            msg.setSubject("Đặt lại mật khẩu - EVSWAP");
            msg.setText("Xin chào " + driver.getFullName()
                    + ",\nMã OTP của bạn là: " + otp + "\nCó hiệu lực trong 10 phút.");
            mailSender.send(msg);
        } catch (Exception ex) {
            redirect.addFlashAttribute("error", "Không thể gửi email: " + ex.getMessage());
            return "redirect:/forgot-password";
        }

        redirect.addFlashAttribute("success", "OTP đã được gửi đến email của bạn.");
        return "redirect:/reset-password?email=" + email;
    }

    // ===== RESET PASSWORD =====
    @GetMapping("/reset-password")
    public String resetPasswordForm(@RequestParam(value = "email", required = false) String email, Model model) {
        model.addAttribute("email", email);
        return "reset-password";
    }

    @PostMapping("/reset-password")
    public String handleResetPassword(@RequestParam("email") @NotBlank String email,
                                      @RequestParam("otp") @NotBlank String otp,
                                      @RequestParam("newPassword") @NotBlank String newPassword,
                                      RedirectAttributes redirect) {
        Optional<Driver> opt = driverRepository.findByEmail(email);
        if (opt.isEmpty()) {
            redirect.addFlashAttribute("error", "Email không hợp lệ.");
            return "redirect:/reset-password?email=" + email;
        }

        Driver driver = opt.get();
        if (driver.getEmailOtp() == null || driver.getOtpExpiry() == null
                || Instant.now().isAfter(driver.getOtpExpiry())
                || !driver.getEmailOtp().equals(otp)) {
            redirect.addFlashAttribute("error", "Mã OTP không hợp lệ hoặc đã hết hạn.");
            return "redirect:/reset-password?email=" + email;
        }

        driver.setPasswordHash(passwordEncoder.encode(newPassword));
        driver.setEmailOtp(null);
        driver.setOtpExpiry(null);
        driverRepository.save(driver);

        redirect.addFlashAttribute("success", "Đặt lại mật khẩu thành công!");
        return "redirect:/login";
    }

    private String generateOtp() {
        return String.valueOf(100000 + new Random().nextInt(900000));
    }
}
