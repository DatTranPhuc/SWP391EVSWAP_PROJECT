package evswap.swp391to4.controller;

import evswap.swp391to4.entity.Driver;
import evswap.swp391to4.entity.Vehicle;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
public class AccountController {

    @GetMapping("/account")
    public String showAccountPage(HttpSession session, Model model) {
        Driver driver = (Driver) session.getAttribute("loggedInDriver");

        if (driver == null) {
            return "redirect:/login";
        }

        model.addAttribute("driverName", driver.getFullName());
        model.addAttribute("driverEmail", driver.getEmail());
        model.addAttribute("driverPhone", driver.getPhone());

        // ✅ Kiểm tra thật kỹ phần getVehicles()
        List<Vehicle> vehicles = new ArrayList<>();
        try {
            if (driver.getVehicles() != null) {
                vehicles = driver.getVehicles();
            }
        } catch (Exception e) {
            // Ghi log ra console để kiểm tra
            System.out.println("⚠️ Không thể lấy danh sách xe: " + e.getMessage());
        }

        model.addAttribute("vehicles", vehicles);

        return "account";
    }
}
